﻿![](documentation/presentation-images/intro.png)



# <span style="color:Green">What is the problem?</span>



![](documentation/presentation-images/problems.png)



# <span style="color:Green">How ScamLock provides solution?</span>

![](documentation/presentation-images/flowdiagram.png)

# <span style="color:Green">What is the solution?</span>

<All Screenshots>





# <span style="color:Green">What are the benefits?</span>

![](documentation/presentation-images/advantages.png)

## <span style="color:Green">Technical overview:</span>

1. **Environment Configuration:**
   - **Operating System:** Windows 10 Enterprise edition 64-bit operating system
   - **Installed Memory (RAM):** 8 GB
   - **Application software(s):**
     - Angular 8.0.3 for UI
     - Java version 1.8
     - node 10.20.1
     - node package manager 6.7.0
     - Spring boot 2.0.1 version as backend technology
     - Verhoeff algorithm for AAdhar validation
     - JWT token authentication for API security
     - IP tracking for vendor login
     - Embedded tomcat server for deploying the backend application
     - Editors:
       1. Eclipse neon backend
       2. Atom for UI
     - Chatbot
       	1. Gupshup chatbot
     - Email service:
       1. Sendgrid
     - Capcha application:
       1. Google captcha
   - **Database:** MySQL 8.0.20

2. **Additional Tools:**
   * Git version 2.20.1-64-bit for Windows
   * typora-x64 bit for Windows for markdown file creation
   * https://www.draw.io/  (Online design tool)

3. **File Structure and Database relation:** 

   * Refer technical design document: 

4. **High level Architecture:**



# <span style="color:Green">Scope or limitations:</span>

* Mode of availability is only Online.
* The success of this "SmartLock" application depends on cooperation from various entities and vendors.
* High and complex level of approvals are required to implement this tool.
  

# <span style="color:Green">Dependencies </span>

* The tool’s dependency depends on the cooperation from various entities and vendors
* High and complex level of approvals from Government bodies
  

# <span style="color:Green">Future scope:</span>

* Based on our full proof system of storage of data with FIS, "SmartLock" application intend to predict the future cases of fraud based on past and historical data. 
* "SmartLock" application can also predict the government revenue saving in this case with past data.
* Based on historical data we can add a sub tool to predict the credit worthiness of the individuals.



# <span style="color:Green">FAQ:</span>

##### <span style="color:Green">Why this tool?</span>

To reduce the fake investments.

##### <span style="color:Green">Who are entities involved?</span>

Government, Vendors selling investments, FIS as Technical support and IT Return users,

##### <span style="color:Green">Is it mandatory for vendors to register in this tool?</span>

Yes. It should be mandatory by government,

#### <span style="color:Green">What is available in this appication?</span>

Complete list of investment products (valid/invalid) and validation of birth and death certificate.

##### <span style="color:Green">Who is responsible/ accountable to maintain NPI data?</span>

FIS as technical support provider and Government approved bodies.

##### <span style="color:Green">What are the modes of availability of this tool**?**</span>

Online mode. 

##### <span style="color:Green">Will we be allowed to save individual's NPI and PCI?</span>

Yes. FIS as technical support provider need to get approval to implement this tool from the concerned GOI body.

##### <span style="color:Green">Even after registering with our website, what if the NGOs are fake?</span>

No, while registering the offline/ online vendors, "SmartLock" application will validate the authenticity of the vendors and will only list out authentic vendors to the general public.

##### <span style="color:Green">What is the size of the back-end team to serve all the tax filing citizens? The number of people, who filed Income Tax returns was 6.08 crore in the assessment year 2018-19.</span>

Yes, the back-end call center team will work 24/7 to address the queries of concerned individuals.

# <span style="color:Green">References</span>

* Income tax Department ([*www.incometaxindia.gov.in*](http://www.incometaxindia.gov.in)*)*
* GST ([*www.gst.gov.in*](http://www.gst.gov.in))
* Ministry of Company Registration ([*www.mca.gov.in*](http://www.mca.gov.in))
* List of Company Registers (https://en.wikipedia.org/wiki/Ministry_of_Corporate_Affairs )
* Cyber Crime Portal (https://cybercrime.gov.in/)
* UDAI (https://uidai.gov.in/)
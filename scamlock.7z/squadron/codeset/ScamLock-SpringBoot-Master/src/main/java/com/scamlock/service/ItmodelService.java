package com.scamlock.service;

import java.util.List;

import com.scamlock.model.ItmodelDto;
import com.scamlock.model.Itmodel;

public interface ItmodelService {

	Itmodel save(ItmodelDto user);

	List<Itmodel> findAll();

	void delete(int id);

	Itmodel findOne(String username);

	Itmodel findById(int id);

	ItmodelDto update(ItmodelDto userDto);

	Itmodel validate(int id);
}

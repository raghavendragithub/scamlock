package com.scamlock.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.scamlock.dao.CustomerDao;
import com.scamlock.dao.UserDao;
import com.scamlock.model.Customer;
import com.scamlock.model.CustomerDto;
import com.scamlock.model.User;
import com.scamlock.service.CustomerService;

import ch.qos.logback.core.net.SyslogOutputStream;

@Transactional
@Service(value = "customerService")
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private CustomerDao customerDao;
	@Autowired
	private UserDao userDao;

	@Autowired
	private BCryptPasswordEncoder bcryptEncoder;

	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		User user = userDao.findByUsername(username);
		if (user == null) {
			throw new UsernameNotFoundException("Invalid username or password.");
		}
		return new org.springframework.security.core.userdetails.User(user.getUsername(), user.getPassword(),
				getAuthority());
	}

	private List<SimpleGrantedAuthority> getAuthority() {
		return Arrays.asList(new SimpleGrantedAuthority("ROLE_ADMIN"));
	}

	public List<Customer> findAll() {
		List<Customer> list = new ArrayList<>();
		customerDao.findAll().iterator().forEachRemaining(list::add);
		return list;
	}

	@Override
	public void delete(int id) {
		customerDao.deleteById(id);
	}

	@Override
	public Customer findOne(String username) {
		return customerDao.findByName(username);
	}

	@Override
	public Customer findById(int id) {
		Optional<Customer> optionalUser = customerDao.findById(id);
		return optionalUser.isPresent() ? optionalUser.get() : null;
	}

	@Override
	public CustomerDto update(CustomerDto userDto) {
		Customer user = findById(userDto.getId());
		if (user != null) {
			BeanUtils.copyProperties(userDto, user, "password", "username");
			customerDao.save(user);
		}
		return userDto;
	}

	@Override
	public

	Customer validate(int id) {
		System.out.println("77777777777777777777777777777777777");
		System.out.println("77777777777777777777777777777777777");

		System.out.println("77777777777777777777777777777777777");

		System.out.println("77777777777777777777777777777777777");

		System.out.println("77777777777777777777777777777777777");

		System.out.println("77777777777777777777777777777777777");

		System.out.println("77777777777777777777777777777777777");

		Customer user = findById(id);
		user.setStatus("True");
		customerDao.save(user);

		return user;

	}

	@Override
	public Customer save(CustomerDto user) {

		Customer newUser = new Customer();

		newUser.setAadhar(user.getAadhar());
		newUser.setName(user.getName());
		newUser.setEmail(user.getEmail());
		newUser.setAmount(user.getAmount());
		newUser.setPan(user.getPan());
		newUser.setSection(user.getSection());
		newUser.setTodayDate(user.getTodayDate());

		return customerDao.save(newUser);
	}

}

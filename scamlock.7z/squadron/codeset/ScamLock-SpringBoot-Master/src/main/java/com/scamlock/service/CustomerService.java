package com.scamlock.service;

import java.util.List;

import com.scamlock.model.Customer;
import com.scamlock.model.CustomerDto;

public interface CustomerService {

	Customer save(CustomerDto user);

	List<Customer> findAll();

	void delete(int id);

	Customer findOne(String username);

	Customer findById(int id);

	CustomerDto update(CustomerDto userDto);

	Customer validate(int id);
}

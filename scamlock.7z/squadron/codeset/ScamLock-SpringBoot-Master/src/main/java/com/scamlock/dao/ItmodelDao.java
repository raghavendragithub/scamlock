package com.scamlock.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.scamlock.model.Itmodel;

@Repository
public interface ItmodelDao extends CrudRepository<Itmodel, Integer> {

	Itmodel findByName(String name);
}

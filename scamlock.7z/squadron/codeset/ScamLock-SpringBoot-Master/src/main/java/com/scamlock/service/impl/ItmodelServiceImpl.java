package com.scamlock.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.scamlock.dao.CustomerDao;
import com.scamlock.dao.ItmodelDao;
import com.scamlock.dao.UserDao;
import com.scamlock.model.Customer;
import com.scamlock.model.Itmodel;
import com.scamlock.model.ItmodelDto;
import com.scamlock.model.User;
import com.scamlock.service.ItmodelService;

@Transactional
@Service(value = "itmodelService")
public class ItmodelServiceImpl implements ItmodelService {

	@Autowired
	private ItmodelDao customerDao;
	@Autowired
	private CustomerDao itDao;

	@Autowired
	private UserDao userDao;

	@Autowired
	private BCryptPasswordEncoder bcryptEncoder;

	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		User user = userDao.findByUsername(username);
		if (user == null) {
			throw new UsernameNotFoundException("Invalid username or password.");
		}
		return new org.springframework.security.core.userdetails.User(user.getUsername(), user.getPassword(),
				getAuthority());
	}

	private List<SimpleGrantedAuthority> getAuthority() {
		return Arrays.asList(new SimpleGrantedAuthority("ROLE_ADMIN"));
	}

	public List<Itmodel> findAll() {
		List<Itmodel> list = new ArrayList<>();
		customerDao.findAll().iterator().forEachRemaining(list::add);
		return list;
	}

	@Override
	public void delete(int id) {
		customerDao.deleteById(id);
	}

	@Override
	public Itmodel findOne(String username) {
		return customerDao.findByName(username);
	}

	@Override
	public Itmodel findById(int id) {
		Optional<Itmodel> optionalUser = customerDao.findById(id);
		return optionalUser.isPresent() ? optionalUser.get() : null;
	}

	@Override
	public ItmodelDto update(ItmodelDto userDto) {
		Itmodel user = findById(userDto.getId());
		if (user != null) {
			BeanUtils.copyProperties(userDto, user, "password", "username");
			customerDao.save(user);
		}
		return userDto;
	}

	@Override
	public

			Itmodel validate(int id) {

		Itmodel user = findById(id);
		user.setStatus("True");
		customerDao.save(user);

		return user;

	}

	@Override
	public Itmodel save(ItmodelDto user) {

		Itmodel newUser = new Itmodel();
		

		for (Customer s : itDao.findAll()) {
			if (user.getAadhar().matches(s.getAadhar()) && (user.getSection() == s.getSection())
					&& user.getStatus().matches(s.getStatus())) {
				newUser.setAadhar(user.getAadhar());
				newUser.setStatus(user.getStatus());

				newUser.setName(user.getName());
				newUser.setEmail(user.getEmail());
				newUser.setAmount(user.getAmount());
				newUser.setPan(user.getPan());
				newUser.setSection(user.getSection());
				newUser.setTodayDate(user.getTodayDate());

			} else {

				throw new UsernameNotFoundException("Not authorized");

			}
		}
		return customerDao.save(newUser);

	}

}

import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { ListReportedissuesComponent } from './user/list-reportedissues/list-reportedissues.component';

import { ListCustomerComponent } from './user/list-customer/list-customer.component';
import { LoginComponent } from './login/login.component';

import { HelpdeskComponent } from './helpdesk/helpdesk.component';
import { ItreturnComponent } from './itreturn/itreturn.component';

import { AddHelpdeskComponent } from './user/add-helpdesk/add-helpdesk.component';


import { AddUserComponent } from './user/add-user/add-user.component';
import { AddCustomerComponent } from './user/add-customer/add-customer.component';
import { AddItComponent } from './user/add-it/add-it.component';

import { EditCustomerComponent } from './user/edit-customer/edit-customer.component';
import {routing} from "./app.routing";
import {ReactiveFormsModule} from "@angular/forms";
import {ApiService} from "./service/api.service";
import {ApiCustomer} from "./service/api.customer";
import {ApiItfiling} from "./service/api.Itfiling";




import {HTTP_INTERCEPTORS, HttpClientModule} from "@angular/common/http";
import {TokenInterceptor} from "./core/interceptor";

@NgModule({
  declarations: [
    AddItComponent,
    AppComponent,
    ItreturnComponent,
    ListCustomerComponent,
    LoginComponent,
    AddUserComponent,
    EditCustomerComponent,
    AddCustomerComponent,
    HelpdeskComponent,
    AddHelpdeskComponent,
    ListReportedissuesComponent
  ],
  imports: [
    BrowserModule,
    routing,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [ApiService,ApiCustomer,ApiItfiling, {provide: HTTP_INTERCEPTORS,
    useClass: TokenInterceptor,
    multi : true}],
  bootstrap: [AppComponent]
})
export class AppModule { }

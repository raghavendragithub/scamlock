export class Itmodel {

  id: number;

}

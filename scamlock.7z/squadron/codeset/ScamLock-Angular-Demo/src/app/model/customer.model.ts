export class Customer {

  id: number;

}

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {Customer} from "../model/customer.model";
import {Observable} from "rxjs/index";
import {ApiResponse} from "../model/api.response";

@Injectable()
export class ApiCustomer {

  constructor(private http: HttpClient) { }
  baseUrl: string = 'http://localhost:8081/customers/';

  login(loginPayload) : Observable<ApiResponse> {
    return this.http.post<ApiResponse>('http://localhost:8081/' + 'token/generate-token', loginPayload);
  }

  getCustomers() : Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl);
  }

  getCustomerById(id: number): Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl + id);
  }

  createCustomer(user: Customer): Observable<ApiResponse> {
    return this.http.post<ApiResponse>(this.baseUrl, user);
  }

  updateCustomer(user: Customer): Observable<ApiResponse> {
    return this.http.put<ApiResponse>(this.baseUrl + user.id, user);
  }

  deleteCustomer(id: number): Observable<ApiResponse> {
    return this.http.delete<ApiResponse>(this.baseUrl + id);
  }

  validateCustomer(id: number): Observable<ApiResponse> {
    return this.http.put<ApiResponse>(this.baseUrl + id,{});
  }
}

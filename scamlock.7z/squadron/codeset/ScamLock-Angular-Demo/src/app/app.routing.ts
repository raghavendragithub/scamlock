import { RouterModule, Routes } from '@angular/router';
import {LoginComponent} from "./login/login.component";

import {HelpdeskComponent} from "./helpdesk/helpdesk.component";
import {ItreturnComponent} from "./itreturn/itreturn.component";

import {AddHelpdeskComponent} from "./user/add-helpdesk/add-helpdesk.component";

import {AddUserComponent} from "./user/add-user/add-user.component";
import {ListCustomerComponent} from "./user/list-customer/list-customer.component";
import {ListItreturnsComponent} from "./user/list-itreturns/list-itreturns.component";

import {ListReportedissuesComponent} from "./user/list-reportedissues/list-reportedissues.component";
import {EditCustomerComponent} from "./user/edit-customer/edit-customer.component";
import {AddCustomerComponent} from "./user/add-customer/add-customer.component";
import {AddItComponent} from "./user/add-it/add-it.component";

const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'itreturn', component: ItreturnComponent },


  { path: 'helpdesk', component: HelpdeskComponent },


  { path: 'add-user', component: AddUserComponent },
  { path: 'add-helpdesk', component: AddHelpdeskComponent },
  { path: 'add-it', component: AddItComponent },


  { path: 'add-customer', component: AddCustomerComponent },
  { path: 'list-itreturns', component: ListItreturnsComponent },

  { path: 'list-reportedissues', component: ListReportedissuesComponent },

  { path: 'list-customer', component: ListCustomerComponent },
  { path: 'edit-customer', component: EditCustomerComponent },
  {path : '', component : LoginComponent}
];

export const routing = RouterModule.forRoot(routes);

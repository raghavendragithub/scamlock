import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {Router} from "@angular/router";
import {ApiCustomer} from "../../service/api.customer";

@Component({
  selector: 'app-add-customer',
  templateUrl: './add-customer.component.html',
  styleUrls: ['./add-customer.component.css']
})
export class AddCustomerComponent implements OnInit {

  constructor(private formBuilder: FormBuilder,private router: Router, private apiService: ApiCustomer) { }

  addForm: FormGroup;
  todayDate : Date ;



  ngOnInit() {
    this.addForm = this.formBuilder.group({
      id: [],
      name: [''],
      aadhar: ['', Validators.required],
      email: ['', Validators.required],
      pan: ['', Validators.required],
      section: ['', Validators.required],
      amount: ['', Validators.required],

    });

  }

  onSubmit() {
    this.addForm.value.todayDate=new Date();
    alert(JSON.stringify(this.addForm.value));
    this.apiService.createCustomer(this.addForm.value)
      .subscribe( data => {
        this.router.navigate(['list-customer']);
      });
  }

}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddItComponent } from './add-it.component';

describe('AddItComponent', () => {
  let component: AddCustomerComponent;
  let fixture: ComponentFixture<AddItComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddItComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddItComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

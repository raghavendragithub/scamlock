import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {Router} from "@angular/router";

import {ApiItfiling} from "../../service/api.Itfiling";


@Component({
  selector: 'app-add-it',
  templateUrl: './add-it.component.html',
  styleUrls: ['./add-it.component.css']
})
export class AddItComponent implements OnInit {

  constructor(private formBuilder: FormBuilder,private router: Router, private apiService: ApiItfiling) { }

  addForm: FormGroup;
  todayDate : Date ;



  ngOnInit() {
    this.addForm = this.formBuilder.group({
      id: [],
      name: [''],
      aadhar: ['', Validators.required],
      email: ['', Validators.required],
      pan: ['', Validators.required],
      section: ['', Validators.required],
      amount: ['', Validators.required],

    });

  }

  onSubmit() {
    this.addForm.value.todayDate=new Date();
    alert(JSON.stringify(this.addForm.value));
    this.apiService.createCustomer(this.addForm.value)
      .subscribe( data => {
        this.router.navigate(['list-itreturns']);
      });
  }

}

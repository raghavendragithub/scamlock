import { Component, OnInit , Inject} from '@angular/core';
import {Router} from "@angular/router";
import {Customer} from "../../model/customer.model";
import {ApiCustomer} from "../../service/api.customer";
import {Component} from '@angular/core';

@Component({
  selector: 'app-list-customer',
  templateUrl: './list-customer.component.html',
  styleUrls: ['./list-customer.component.css']
})
export class ListCustomerComponent implements OnInit {

  users: Customer[];

  constructor(private router: Router, private apiService: ApiCustomer) { }

  ngOnInit() {
    if(!window.localStorage.getItem('token')) {
      this.router.navigate(['login']);
      return;
    }
    this.apiService.getCustomers()
      .subscribe( data => {
        this.users = data.result;
      });
  }
openDialog(){
  alert("HHHHHHI")
}
  deleteUser(user: Customer): void {
    this.apiService.deleteCustomer(user.id)
      .subscribe( data => {
        this.users = this.users.filter(u => u !== user);
      })
  };


  printPage() {
   window.print();
 }

  editUser(user: Customer): void {
    window.localStorage.removeItem("editUserId");
    window.localStorage.setItem("editUserId", user.id.toString());
    this.router.navigate(['edit-customer']);
  };

  addCustomer(): void {
    this.router.navigate(['add-customer']);
  };
}

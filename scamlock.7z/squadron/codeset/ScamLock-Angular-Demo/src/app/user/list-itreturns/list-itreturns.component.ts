import { Component, OnInit , Inject} from '@angular/core';
import {Router} from "@angular/router";
import {Itmodel} from "../../model/itmodel.model";
import {ApiItfiling} from "../../service/api.Itfiling";

@Component({
  selector: 'app-list-itreturns',
  templateUrl: './list-itreturns.component.html',
  styleUrls: ['./list-itreturns.component.css']
})
export class ListItreturnsComponent implements OnInit {
  isCollapsed = false;

  users: Itmodel[];

  constructor(private router: Router, private apiService: ApiItfiling) { }

  ngOnInit() {

    if(!window.localStorage.getItem('token')) {
      this.router.navigate(['itreturn']);
      return;
    }
    this.apiService.getCustomers()
      .subscribe( data => {

        this.users = data.result;
      });
  }

  deleteUser(user: Itmodel): void {
    this.apiService.deleteCustomer(user.id)
      .subscribe( data => {
        this.users = this.users.filter(u => u !== user);
      })
  };


  printPage() {
   window.print();
 }

  editUser(user: Itmodel): void {
    window.localStorage.removeItem("editUserId");
    window.localStorage.setItem("editUserId", user.id.toString());
    this.router.navigate(['edit-customer']);
  };

  addCustomer(): void {
    this.router.navigate(['add-it']);
  };
}

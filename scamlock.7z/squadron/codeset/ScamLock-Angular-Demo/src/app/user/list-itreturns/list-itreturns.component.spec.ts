import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListItreturnsComponent } from './list-itreturns.component';

describe('ListItreturnsComponent', () => {
  let component: ListItreturnsComponent;
  let fixture: ComponentFixture<ListItreturnsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListItreturnsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListItreturnsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

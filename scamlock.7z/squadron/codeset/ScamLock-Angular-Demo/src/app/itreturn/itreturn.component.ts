import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {Router} from "@angular/router";
import {ApiService} from "../service/api.service";
declare var grecaptcha: any;

@Component({
  selector: 'app-itreturn',
  templateUrl: './itreturn.component.html',
  styleUrls: ['./itreturn.component.css']
})
export class ItreturnComponent implements OnInit {

  loginForm: FormGroup;
  submitted: boolean = false;

  invalidLogin: boolean = false;
  captchaError: boolean = false;

  constructor(private formBuilder: FormBuilder, private router: Router, private apiService: ApiService) { }

  onSubmit() {
    if (this.loginForm.invalid) {
      return;
    }
    const response = grecaptcha.getResponse();
   if (response.length === 0) {
     this.captchaError = true;
     return;
   }
    const loginPayload = {
      username: this.loginForm.controls.username.value,
      password: this.loginForm.controls.password.value
    }
    this.apiService.login(loginPayload).subscribe(data => {
      debugger;
      if(data.status === 200) {
        window.localStorage.setItem('token', data.result.token);
        this.router.navigate(['list-itreturns']);
      }else {
        this.invalidLogin = true;
        alert(data.message);
      }
    });
  }

  ngOnInit() {
    window.localStorage.removeItem('token');
    this.loginForm = this.formBuilder.group({
      username: ['', Validators.compose([Validators.required])],
      password: ['', Validators.required]
    });
  }



}

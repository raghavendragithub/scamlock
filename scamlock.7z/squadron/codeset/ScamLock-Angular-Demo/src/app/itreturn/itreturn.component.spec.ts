import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ItreturnComponent } from './itreturn.component';

describe('ItreturnComponent', () => {
  let component: ItreturnComponent;
  let fixture: ComponentFixture<ItreturnComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ItreturnComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ItreturnComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
